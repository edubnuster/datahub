# -*- coding: utf-8 -*-
from pathlib import Path
import sys

APP_TITLE = "DataHub"
CONFIG_FILENAME = "config.json"
AUDIT_FILENAME = "audit.log"
LICENSE_FILENAME = "databrev.key"
LICENSE_SECRET = "DATABREV-LICENSE-2026"

MASTER_USERNAME = "databrev"
MASTER_PASSWORD = "270810"

DEFAULT_LIST_SQL = """
select
    c.grid as customer_id,
    pessoa_nome_f(l.empresa) as last_purchase_company,
    c.codigo as customer_code,
    c.nome as customer_name,
    coalesce(co.nome, 'Sem conta') as account_name,
    max(case when pc.pessoa is not null then 1 else 0 end) as has_account,
    coalesce(pc.lim_credito, 0) as credit_limit,
    max(l.data) as last_purchase_date,
    case c.flag
        when 'A' then 'Ativo'
        when 'I' then 'Inativo'
        when 'D' then 'Deletado'
        else coalesce(c.flag, '')
    end as customer_status
from cliente c
join lancto l
    on l.pessoa = c.grid
left join pessoa_conta pc
    on pc.pessoa = c.grid
left join conta co
    on co.codigo = pc.conta
where l.operacao = 'V'
group by
    c.grid,
    l.empresa,
    c.codigo,
    c.nome,
    coalesce(co.nome, 'Sem conta'),
    coalesce(pc.lim_credito, 0),
    c.flag,
    pessoa_nome_f(l.empresa)
having max(l.data) < current_date - interval '3 months'
order by pessoa_nome_f(l.empresa), max(l.data)
"""

DEFAULT_CONFIG = {
    "connection": {
        "host": "127.0.0.1",
        "port": 5432,
        "dbname": "",
        "user": "postgres",
        "password": "",
        "client_encoding": "LATIN1",
    },
    "security": {
        "users": []
    },
    "queries": {
        "list_inactive_customers_sql": DEFAULT_LIST_SQL,
        "delete_customer_sql": """
            update cliente
               set flag = 'D'
             where grid = %(customer_id)s
        """,
        "inactivate_customer_sql": """
            update cliente
               set flag = 'I'
             where grid = %(customer_id)s
        """,
        "disable_credit_sql": """
            update pessoa_conta pc
               set lim_credito = 0
             where pc.pessoa = %(customer_id)s
        """
    }
}

def app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent

CONFIG_PATH = app_dir() / CONFIG_FILENAME
AUDIT_PATH = app_dir() / AUDIT_FILENAME
LICENSE_PATH = app_dir() / LICENSE_FILENAME
