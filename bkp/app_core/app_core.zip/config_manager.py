# -*- coding: utf-8 -*-
import json
from copy import deepcopy
from typing import Any, Dict
from .constants import CONFIG_PATH, DEFAULT_CONFIG, DEFAULT_LIST_SQL

class ConfigManager:
    @staticmethod
    def exists() -> bool:
        return CONFIG_PATH.exists()

    @staticmethod
    def load() -> Dict[str, Any]:
        if not CONFIG_PATH.exists():
            return deepcopy(DEFAULT_CONFIG)

        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)

        merged = deepcopy(DEFAULT_CONFIG)
        ConfigManager._deep_update(merged, data)

        if "users" not in merged.get("security", {}):
            merged["security"]["users"] = []

        current_sql = merged.get("queries", {}).get("list_inactive_customers_sql", "") or ""
        current_sql_lower = current_sql.lower()
        if (
            "left join pessoa_conta" not in current_sql_lower
            or "credit_limit" not in current_sql
            or "has_account" not in current_sql_lower
        ):
            merged["queries"]["list_inactive_customers_sql"] = DEFAULT_LIST_SQL

        if not (merged.get("queries", {}).get("delete_customer_sql") or "").strip():
            merged["queries"]["delete_customer_sql"] = DEFAULT_CONFIG["queries"]["delete_customer_sql"]
        if not (merged.get("queries", {}).get("inactivate_customer_sql") or "").strip():
            merged["queries"]["inactivate_customer_sql"] = DEFAULT_CONFIG["queries"]["inactivate_customer_sql"]
        disable_sql = (merged.get("queries", {}).get("disable_credit_sql") or "").strip().lower()
        if not disable_sql or "update conta" in disable_sql:
            merged["queries"]["disable_credit_sql"] = DEFAULT_CONFIG["queries"]["disable_credit_sql"]

        return merged

    @staticmethod
    def save(data: Dict[str, Any]) -> None:
        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)

    @staticmethod
    def _deep_update(base: Dict[str, Any], incoming: Dict[str, Any]) -> None:
        for key, value in incoming.items():
            if isinstance(value, dict) and isinstance(base.get(key), dict):
                ConfigManager._deep_update(base[key], value)
            else:
                base[key] = value
