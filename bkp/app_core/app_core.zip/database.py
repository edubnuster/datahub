# -*- coding: utf-8 -*-
from typing import Any, Dict, List
import psycopg2
import psycopg2.extras
from .helpers import AppError

class Database:
    def __init__(self, config: Dict[str, Any]):
        self.config = config

    def _connect(self):
        conn_cfg = self.config["connection"]
        conn = psycopg2.connect(
            host=conn_cfg["host"],
            port=conn_cfg["port"],
            dbname=conn_cfg["dbname"],
            user=conn_cfg["user"],
            password=conn_cfg["password"],
            connect_timeout=8,
        )
        enc = (conn_cfg.get("client_encoding") or "").strip()
        if enc:
            conn.set_client_encoding(enc)
        return conn

    def test_connection(self):
        with self._connect() as conn:
            with conn.cursor() as cur:
                cur.execute("select 1")
                cur.fetchone()

    def list_inactive_customers(self) -> List[Dict[str, Any]]:
        sql_text = (self.config.get("queries", {}).get("list_inactive_customers_sql") or "").strip()
        if not sql_text:
            raise AppError("A query de listagem não está configurada.")
        with self._connect() as conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(sql_text)
                return [dict(r) for r in cur.fetchall()]

    def execute_action(self, sql_text: str, customer_ids: List[Any]) -> int:
        if not (sql_text or "").strip():
            raise AppError("SQL da ação não configurada.")
        total = 0
        with self._connect() as conn:
            try:
                with conn.cursor() as cur:
                    for customer_id in customer_ids:
                        cur.execute(sql_text, {"customer_id": customer_id})
                        if cur.rowcount and cur.rowcount > 0:
                            total += cur.rowcount
                conn.commit()
            except Exception:
                conn.rollback()
                raise
        return total
