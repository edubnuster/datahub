# -*- coding: utf-8 -*-
from dataclasses import dataclass
from datetime import date, datetime
from typing import Any, Optional


@dataclass
class CustomerRow:
    customer_id: Any
    customer_code: Any
    customer_name: str
    last_purchase_date: Optional[Any]
    last_purchase_company: Optional[str]
    account_name: Optional[str]
    customer_status: str
    has_account: bool = False
    credit_limit: Any = 0
    selected: bool = False

    def checkbox(self) -> str:
        return "☑" if self.selected else "☐"

    def last_purchase_date_display(self) -> str:
        value = self.last_purchase_date
        if value in (None, ""):
            return "Sem compra"
        if isinstance(value, datetime):
            return value.strftime("%d/%m/%Y %H:%M")
        if isinstance(value, date):
            return value.strftime("%d/%m/%Y")
        return str(value)

    def credit_limit_display(self) -> str:
        value = self.credit_limit
        if value in (None, ""):
            return "0,00"
        try:
            num = float(value)
            return f"{num:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
        except Exception:
            return str(value)
